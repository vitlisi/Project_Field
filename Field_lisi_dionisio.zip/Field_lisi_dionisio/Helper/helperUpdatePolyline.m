function helperUpdatePolyline(hPoly, x, y)
%helperUpdatePolyline Update polyline position
%   helperUpdatePolyline updates the polyline ROI object hPoly to add a
%   point at [x,y].

hPoly.Position(end+1,:) = [x y];
end