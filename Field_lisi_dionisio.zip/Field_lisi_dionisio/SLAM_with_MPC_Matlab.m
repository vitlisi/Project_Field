%% SECTION 1: Load Data and Visualize Path
clc; clear all; close all;
addpath("Helper");
addpath("file.MAT");

% Load reference poses and curvature data
xData       = load('refPosesX.mat');
yData       = load('refPosesY.mat');
yawData     = load('refPosesT.mat');

% Extract variables from files
refPosesX   = xData.refPosesX;
refPosesY   = yData.refPosesY;
refPosesT   = yawData.refPosesT;

% Scene visualization
sceneName = 'USCityBlock';
hScene = figure;
helperShowSceneImage(sceneName);
hold on;
scatter(refPosesX(:,2), refPosesY(:,2), 7, 'filled');
xlim([-150 100]);
ylim([-125 75]);
close(hScene);

%% SECTION 2: Simulink Setup
modelName = 'SLAM_with_MPC_Simulink';
open_system(modelName);
snapnow;

% Simulation stop time
simStopTime = 175; 
set_param(modelName, 'StopTime', num2str(simStopTime));

%% SECTION 3: Load INS Measurements
% Load INS data
data = load("insMeasurement.mat");
insMeasurement = data.insMeasurement;

% Export to base workspace for Simulink
assignin('base', 'insMeasurement', insMeasurement);

% Internal use for SLAM loop
insData = insMeasurement.signals.values;

%% SECTION 4: Simulation and SLAM
simOut = sim(modelName);
ptCloudArr = helperGetPointCloud(simOut);

% SLAM map builder
rng(0);
mapBuilder = helperLidarMapBuilder('DownsampleGridStep',0.25,'Verbose',true);
configureLoopDetector(mapBuilder, 'LoopConfirmationRMSE',1.5,'SearchRadius',0.15,'DistanceThreshold',0.2);

% SLAM loop parameters
skipFrames = 10;
numFrames  = numel(ptCloudArr);
exitLoop   = false;
prevInsMeas = insData(1,:);

for n = 1:skipFrames:numFrames
    insMeas = insData(n,:);
    initTform = helperEstimateRelativeTransformationFromINS(insMeas, prevInsMeas);

    % Filter valid points
    validIdx = all(isfinite(ptCloudArr(n).Location), 2);
    numValidPoints = sum(validIdx);

    if numValidPoints < 3
        warning("Frame %d has less than 3 valid points (%d only): skipped.", n, numValidPoints);
        continue;
    end

    % Update map and display
    updateMap(mapBuilder, ptCloudArr(n), initTform);
    isDisplayOpen = updateDisplay(mapBuilder, exitLoop);
    exitLoop = ~isDisplayOpen;
    prevInsMeas = insMeas;
end

snapnow;
updateDisplay(mapBuilder, true);

%% SECTION 5: SLAM Optimization
hFigViewset = figure;
hG = plot(mapBuilder.ViewSet);
view(hG.Parent, 2);
title('View Set Display');

% Trajectory before optimization
estimatedTrajectoryBefore = vertcat(mapBuilder.ViewSet.Views.AbsolutePose.Translation);

% Pose graph optimization
optimizeMapPoses(mapBuilder);
rebuildMap(mapBuilder);

%% SECTION 6: Build 2D Map from Point Cloud 
xyzPoints = mapBuilder.Map.Location;
zMin = 0.01; zMax = 1.5;
validZ = xyzPoints(:,3) > zMin & xyzPoints(:,3) < zMax;
xyPoints = xyzPoints(validZ, 1:2);

% Map limits
xyMin = floor(min(xyPoints, [], 1));
xyMax = ceil(max(xyPoints, [], 1));
mapWidth = xyMax(1) - xyMin(1);
mapHeight = xyMax(2) - xyMin(2);

% Parameters
resolution = 20;

% Initialize empty map
map2D = occupancyMap(mapWidth, mapHeight, resolution);
map2D.GridLocationInWorld = xyMin;

% Set all cells to weakly free (0.2)
occMatrix = 0.2 * ones(map2D.GridSize);
map2D = occupancyMap(occMatrix, resolution);
map2D.GridLocationInWorld = xyMin;

% Set true obstacles
setOccupancy(map2D, xyPoints, 1);

% Inflate for robot margin
inflate(map2D, 0.8);

% Show map
figure("Name", "2D Occupancy Map");
show(map2D);
title("2D Occupancy Map Generated from 3D Point Cloud");

% Cell statistics
occMatrix = getOccupancy(map2D);
numOccupied = sum(occMatrix(:) > 0.5);
numFree = sum(occMatrix(:) < 0.5);
numUnknown = sum(isnan(occMatrix(:)));
total = numel(occMatrix);

disp("Total cells: " + total);
disp("Occupied: " + numOccupied);
disp("Free: " + numFree);
disp("Unknown (NaN): " + numUnknown);

%  Show SLAM start point from point cloud
startXY = simOut.lidarLocation.signals.values(1, 1:2);

% Print coordinates for verification
disp("SLAM Start Point (Accumulated Point Cloud):");
disp("X: " + startXY(1) + "   Y: " + startXY(2));

figure;
show(map2D);
hold on;
plot(startXY(1), startXY(2), 'go', 'MarkerSize', 10, 'LineWidth', 2);
title("Start of 3D Point Cloud Overlaid on 2D Map");
legend("Map", "Start 3D");

%% SECTION 7: GPS, Reference, and Lidar
% === 1. Extract GPS data (LLA → ENU) ===
rawLLA = simOut.GPS_Location.signals.values;         % [1x3xN]
LLA = squeeze(rawLLA)';                           % [N x 3]
gpsENU = lla2enu(LLA, [37.7748, -122.4196, 0], 'ellipsoid');  % [N x 3]

% === 2. Extract reference trajectory ===
refX = refPosesX(:,2);         % East
refY = refPosesY(:,2);         % North

% === 3. Extract Lidar trajectory ===
rawLidar = simOut.lidarLocation.signals.values;      % [1x3xN]
lidarENU = squeeze(rawLidar)';                    % [N x 3]
lidarX = lidarENU(:,1);                           % East
lidarY = lidarENU(:,2);                           % North

% === 4. First figure: GPS vs Reference ===
figure;
plot(gpsENU(:,1), gpsENU(:,2), 'b.-', 'DisplayName', 'GPS');
hold on;
plot(refX, refY, 'r--', 'DisplayName', 'Reference');
xlabel('East [m]'); ylabel('North [m]');
title('GPS vs Reference');
legend('Location','best');
axis equal; grid on;

% === 5. Second figure: GPS vs Reference vs Lidar ===
figure;
plot(gpsENU(:,1), gpsENU(:,2), 'b.-', 'DisplayName', 'GPS');
hold on;
plot(refX, refY, 'r--', 'DisplayName', 'Reference');
plot(lidarX, lidarY, 'g--', 'DisplayName', 'Lidar SLAM');
xlabel('East [m]'); ylabel('North [m]');
title('GPS, Reference and Lidar');
legend('Location','best');
axis equal; grid on;

% 1. Extract time and position
tGPS   = simOut.GPS_Location.time;
tLidar = simOut.lidarLocation.time;

gpsX = gpsENU(:,1);    % Simulated GPS East
gpsY = gpsENU(:,2);    % Simulated GPS North

lidarX = lidarENU(:,1);  % SLAM East
lidarY = lidarENU(:,2);  % SLAM North

% 2. Interpolate LiDAR trajectory on GPS time
lidarX_interp = interp1(tLidar, lidarX, tGPS, 'linear', 'extrap');
lidarY_interp = interp1(tLidar, lidarY, tGPS, 'linear', 'extrap');

% 3. Compute RMSE LiDAR vs GPS
errorGPS_Lidar = [gpsX, gpsY] - [lidarX_interp, lidarY_interp];
rmseGPS_Lidar = sqrt(mean(sum(errorGPS_Lidar.^2, 2)));

% 4. Display only the meaningful result
fprintf('RMSE between LiDAR SLAM and GPS: %.3f meters\n', rmseGPS_Lidar);


%% Helper Functions
function ptCloudArr = helperGetPointCloud(simOut)
    ptCloudData = simOut.ptCloudData.signals.values;
    ptCloudArr = pointCloud(ptCloudData(:,:,:,1));
    for n = 2 : size(ptCloudData,4)
        ptCloudArr(end+1) = pointCloud(ptCloudData(:,:,:,n));
    end
end

function helperMakeFigurePublishFriendly(hFig)
    if ~isempty(hFig) && isvalid(hFig)
        hFig.HandleVisibility = 'callback';
    end
end
