clc; close all; clear;

%% === LOAD OCCUPANCY MAP ===
load('file.MAT/Occupancy_map.mat');  % occupancyMap
occMatrix = occupancyMatrix(map2D);
occMatrix_rot = rot90(occMatrix);       
mapRotated = occupancyMap(occMatrix_rot, map2D.Resolution);
mapRotated.GridLocationInWorld = [-141, -138]; 
map2D = mapRotated;

% Initial visualization
figure; show(map2D); title('Occupancy Map');
pause(1);

%% === BINARIZATION AND FILTERING ===
gridMatrix = occupancyMatrix(map2D);
gridMatrix(gridMatrix < 0.7) = 0;
gridMatrix(gridMatrix >= 0.7) = 1;
gridMatrix = bwareaopen(gridMatrix, 10);  % Remove small objects

% Info about dimensions and occupied cells
disp("Map dimensions: " + mat2str(size(gridMatrix)));
disp("Total occupied cells: " + sum(gridMatrix(:) == 1));

%% === OBSTACLE EXTRACTION VIA BOUNDING BOX ===
CC = bwconncomp(gridMatrix);
stats = regionprops(CC, 'BoundingBox', 'Area');
stats = stats([stats.Area] >= 20000);  % Minimum area filter

res = 1 / map2D.Resolution;
obstacles = zeros(length(stats), 5);  % [x y theta l w]

for i = 1:length(stats)
    box = stats(i).BoundingBox;
    cx_grid = round(box(1) + box(3)/2);
    cy_grid = round(box(2) + box(4)/2);
    centerWorld = grid2world(map2D, [cy_grid, cx_grid]);
    obstacles(i,:) = [centerWorld(1), centerWorld(2), 0, box(3)*res, box(4)*res];
end

disp("Aggregated obstacles found: " + size(obstacles, 1));

%% === OBSTACLE VISUALIZATION ===
figure("Name", "Occupancy Map with Obstacles");
show(map2D); hold on;
title("Occupancy Map + Aggregated Obstacles");

for i = 1:size(obstacles,1)
    x = obstacles(i,1); y = obstacles(i,2);
    l = obstacles(i,4); w = obstacles(i,5);
    rectangle('Position', [x - l/2, y - w/2, l, w], ...
              'FaceColor', 'r', 'EdgeColor', 'k', 'LineWidth', 0.5);
end
xlabel('X (m)'); ylabel('Y (m)');
axis equal; grid on;
pause(1);

%% === PATH PLANNING PARAMETERS ===
num_obstacles = size(obstacles,1);
inflation_radius = 1;

poses = [
    -17, -11,  1.57;
    -17,  40,  1.57;
    -8,   52,  0.00;
     15,  50,  0.00;
     17,  53,  1.57;
     14,  56,  3.14;
    -19,  55,  3.14;
    -25,   3,  3.14;
    -60,   2,  3.14
];

fullPath = [];

%% === SIMULATION FOR EACH SEGMENT ===
for i = 1:size(poses,1)-1
    Start_pose = poses(i,:);
    Goal_pose  = poses(i+1,:);
    fprintf(" Simulation %d: [%0.1f, %0.1f] → [%0.1f, %0.1f]\n", ...
        i, Start_pose(1), Start_pose(2), Goal_pose(1), Goal_pose(2));
    
    out = sim("Path_Planning");
    pathSegment = out.Planner;
    
    if isempty(pathSegment)
        warning(" No path found for segment %d!", i);
        continue;
    end
    
    fullPath = [fullPath; pathSegment];
end

% Separate coordinates
X_path = fullPath(:,1);
Y_path = fullPath(:,2);
Theta_path = fullPath(:,3);

%% === COMPLETE PATH VISUALIZATION ===
figure("Name", "Multi-Segment Path");
show(map2D); hold on;
title("Simulated Path: Start → Goal");
plot(X_path, Y_path, 'b-', 'LineWidth', 2);
plot(poses(:,1), poses(:,2), 'ko', 'MarkerSize', 8, 'LineWidth', 1.5);
text(poses(:,1)+1, poses(:,2), compose("P%d", (0:size(poses,1)-1)'));
legend('Path', 'Waypoints');
xlabel('X (m)'); ylabel('Y (m)');
axis equal; grid on;
pause(1);

%% === VELOCITY PROFILE BASED ON CURVATURE ===
X_smooth = movmean(X_path, 5);
Y_smooth = movmean(Y_path, 5);

dx = gradient(X_smooth); dy = gradient(Y_smooth);
ddx = gradient(dx); ddy = gradient(dy);
curvature = (dx .* ddy - dy .* ddx) ./ (dx.^2 + dy.^2).^(3/2);
curvature(abs(curvature) > 10) = NaN;

curvature_threshold = 0.08;
v_curve = 1.0; v_straight = 2.5;
buffer = 3;
is_curve = abs(curvature) >= curvature_threshold;

for i = find(is_curve)'
    is_curve(max(1,i-buffer):min(end,i+buffer)) = true;
end

v_profile = ones(size(curvature)) * v_straight;
v_profile(is_curve) = v_curve;
v_profile = movmean(v_profile, 3);
Vel_path = v_profile;

% Plot velocity profile
figure;
scatter(X_path, Y_path, 20, v_profile, 'filled');
axis equal;
xlabel('X [m]'); ylabel('Y [m]');
title('Velocity profile');
colormap(jet); colorbar; caxis([1, 2.5]);
pause(1);

%% === TRAJECTORY FOLLOWING SIMULATION ===
modelName = 'Trajectory_Following_Simulink';
open_system(modelName);                      
set_param(modelName, 'StopTime', '150');     

out = sim(modelName);                        
pause(1);

% Extract actual position (from Simulink output)
posizione = out.Actual_Pose.signals.values;
n = size(posizione, 3);
posizione_X = squeeze(posizione(1,1,:));
posizione_Y = squeeze(posizione(1,2,:));

%% === COMPARISON VISUALIZATION ===
figure("Name", "Simulation Path on Map");
show(map2D); hold on;
title("Planned vs Actual Path");

plot(X_path, Y_path, 'b-', 'LineWidth', 2);       % Planned
plot(posizione_X, posizione_Y, 'm--', 'LineWidth', 2);  % Simulated

% Start/goal markers
plot(X_path(1), Y_path(1), 'go', 'MarkerSize', 10, 'LineWidth', 2);
text(X_path(1)+1, Y_path(1), 'Start', 'Color', 'g');
plot(X_path(end), Y_path(end), 'ro', 'MarkerSize', 10, 'LineWidth', 2);
text(X_path(end)+1, Y_path(end), 'Goal', 'Color', 'r');

legend('Planned', 'Simulated', 'Start', 'Goal');
xlabel('X (m)'); ylabel('Y (m)');
axis equal; grid on;
